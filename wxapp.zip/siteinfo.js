var i = {
    uniacid: "43",
    acid: "43",
    multiid: "0",
    version: "v1.0.17",
    siteroot: "https://ww.myudu.com/app/index.php",
    method_design: "3"
};

module.exports = i;